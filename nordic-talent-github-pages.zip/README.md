# Nordic Talent – GitHub Pages

Det här är en fristående webbplats byggd med HTML, CSS och JavaScript. Spelarprofilerna är fiktiva demoprofiler. Klubbnamn och klubbmärken tillhör riktiga föreningar.

## Publicera på GitHub Pages
1. Skapa ett nytt repository på https://github.com/new
2. Döp det exempelvis till `nordic-talent`.
3. Ladda upp `index.html` (eller hela mappen).
4. Öppna repositoryts **Settings → Pages**.
5. Under **Build and deployment**, välj **Deploy from a branch**.
6. Välj `main` och `/ (root)`, tryck **Save**.
7. Efter någon minut visas webbplatsens adress under Pages.

Klubbmärken hämtas från respektive förenings/NFF:s webbplats och kräver internetanslutning.
